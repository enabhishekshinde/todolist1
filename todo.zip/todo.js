const inputbox  = document.getElementById("input-box");
const listcontainer  = document.getElementById("list-container");

function addelement(){

    if(inputbox.value ===''){
        alert("Please write something");
    }else{
        let li = document.createElement("li");
        li.innerHTML = inputbox.value;
        listcontainer.appendChild(li);
    }   
    inputbox.value = "";
}